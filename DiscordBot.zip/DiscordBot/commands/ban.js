module.exports = {
    name: 'ban',
    description: "This command bans a member!",
    execute(message, args){
        if(message.member.roles.cache.has('929875876689100881')){
            const target = message.mentions.users.first();
        if(target){
            const memberTarget = message.guild.members.cache.get(target.id);
            memberTarget.ban();
            message.channel.send("Bozo Got the boot");
        }else{
            message.channel.send(`You cant ban that person dumbass`);
        }
        
        }else{
            message.channel.send('You Ant Got Perms Bozo')
        }
    }
}