module.exports = {
    name: 'nikstwitch',
    description: "this is a command that shows you the other commands",
    execute(message, args){
        message.channel.send('These are the commands! ^ping sends back pong. ^nikstwitch sends Niks twitch Channel (only staff can use this role). ^help sends you This dummy.');
    }
}