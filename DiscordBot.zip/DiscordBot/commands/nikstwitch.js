module.exports = {
    name: 'nikstwitch',
    description: "this is a command that shows you my twitch",
    execute(message, args){

        if(message.member.roles.cache.has('929875876689100881')){
            message.channel.send('https://www.twitch.tv/niksggs');


        }else{
            message.channel.send('You Ant Got Perms Bozo')
        }
        
    }
}