const Discord = require ("discord.js");
const { Intents } = Discord;

const intents = new Intents ();

for(const intent of Object.keys (Intents.FLAGS)){
intents.add(intent);
}

const client = new Discord.Client ({
  intents: intents
});

const prefix = '^';

const fs = require ('fs');

client.commands = new Discord.Collection ();

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){
  const command = require(`./commands/${file}`);

  client.commands.set(command.name, command);
}

client.once('ready', () => {
    console.log('Bravery™ is online!');
});

client.on('guildMemberAdd', guildMember =>{
  let welcomeRole = guildMember.guild.roles.cache.find(role => role.name === '+');

  guildMember.roles.add(welcomeRole);
  guildMember.guild.channels.cache.get('925218847064211559').send(`Welcome <@${guildMember.user.id}> to our server! Make sure to check out the rules channel!`)
});


client.on('message', message =>{
  if(!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  if(command === 'ping'){
    client.commands.get('ping').execute(message, args);
  } else if (command ==  'nikstwitch'){
    client.commands.get('nikstwitch').execute(message, args);
  } else if (command == 'help'){
    client.commands.get('help').execute(message, args);
  }else if (command == 'kick'){
    client.commands.get('kick').execute(message, args);
  }else if (command == 'ban'){
    client.commands.get('ban').execute(message, args);
  }else if (command == 'ticket'){
    client.commands.get('ticket').execute(message, args);
  }
    
});


client.login ('OTI5ODQ3MzMxNjA2NjI2Mzc1.YdtRzw.ghTufbHnQiOLtYJkJ_RgP2UvkMc');
